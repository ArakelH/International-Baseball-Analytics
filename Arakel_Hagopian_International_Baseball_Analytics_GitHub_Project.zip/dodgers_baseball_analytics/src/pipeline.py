"""Reproducible international-born MLB batting analysis (2015-2025)."""
from __future__ import annotations

import argparse
import csv
import io
import json
import sqlite3
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOT = 'https://raw.githubusercontent.com/myceliumdata/lahman-seed/main/lahman_1871-2025_csv'
FILES = ('Batting.csv', 'People.csv')


def download_data(directory: Path) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    for name in FILES:
        target = directory / name
        if target.exists() and target.stat().st_size:
            print(f'Already present: {target}')
            continue
        url = f'{SOURCE_ROOT}/{name}'
        print(f'Downloading {name} from SABR Lahman mirror...')
        with urllib.request.urlopen(url, timeout=90) as response:
            body = response.read()
        if not body or not body.lstrip(b'\xef\xbb\xbf').startswith((b'ID,', b'playerID,')):
            raise ValueError(f'Unexpected data format for {name}')
        target.write_bytes(body)


def read_csv(path: Path):
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def numeric(value):
    try:
        return int(float(value)) if value not in ('', None) else 0
    except (TypeError, ValueError):
        raise ValueError(f'Invalid numeric count: {value!r}')


def load_data(people_rows, batting_rows):
    db = sqlite3.connect(':memory:')
    db.row_factory = sqlite3.Row
    db.executescript('''
      CREATE TABLE people (player_id TEXT PRIMARY KEY, first_name TEXT, last_name TEXT,
        birth_country TEXT, debut TEXT);
      CREATE TABLE batting (player_id TEXT NOT NULL, year INTEGER NOT NULL, stint INTEGER NOT NULL,
        team_id TEXT, ab INTEGER, h INTEGER, doubles INTEGER, triples INTEGER, hr INTEGER,
        bb INTEGER, hbp INTEGER, sf INTEGER, sh INTEGER, PRIMARY KEY (player_id, year, stint));
    ''')
    people = [(r['playerID'].strip(),r.get('nameFirst','').strip(),r.get('nameLast','').strip(),
               r.get('birthCountry','').strip(),r.get('debut','').strip()) for r in people_rows]
    if len(set(r[0] for r in people)) != len(people):
        raise ValueError('Duplicate player IDs in People.csv')
    db.executemany('INSERT INTO people VALUES (?,?,?,?,?)', people)
    rows = []
    for r in batting_rows:
        year = numeric(r.get('yearID'))
        if not 2015 <= year <= 2025:
            continue
        rows.append((r['playerID'].strip(), year, numeric(r.get('stint')), r.get('teamID','').strip(),
                     *[numeric(r.get(k)) for k in ('AB','H','2B','3B','HR','BB','HBP','SF','SH')]))
    if len({(r[0],r[1],r[2]) for r in rows}) != len(rows):
        raise ValueError('Duplicate batting (player, year, stint) records')
    for r in rows:
        ab,h,d,t,hr,bb,hbp,sf,sh = r[4:]
        if min(ab,h,d,t,hr,bb,hbp,sf,sh) < 0 or h > ab or d+t+hr > h:
            raise ValueError(f'Impossible batting line: {r[:3]}')
    db.executemany('INSERT INTO batting VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',rows)
    return db, len(rows)


PLAYER_SQL = '''
WITH player_seasons AS (
 SELECT b.player_id, b.year, p.first_name, p.last_name, p.birth_country,
        SUM(b.ab) AS ab, SUM(b.h) AS h, SUM(b.doubles) AS doubles, SUM(b.triples) AS triples,
        SUM(b.hr) AS hr, SUM(b.bb) AS bb, SUM(b.hbp) AS hbp, SUM(b.sf) AS sf, SUM(b.sh) AS sh
 FROM batting b JOIN people p ON b.player_id = p.player_id
 WHERE p.birth_country NOT IN ('USA', '')
 GROUP BY b.player_id,b.year,p.first_name,p.last_name,p.birth_country
), rates AS (
 SELECT *, ab+bb+hbp+sf+sh AS pa_proxy,
  ROUND(1.0*(h+bb+hbp)/NULLIF(ab+bb+hbp+sf,0),3) AS obp,
  ROUND(1.0*(h+doubles+2*triples+3*hr)/NULLIF(ab,0),3) AS slg
 FROM player_seasons
)
SELECT player_id,year,first_name,last_name,birth_country,ab,h,hr,bb,pa_proxy,
       obp,slg,ROUND(obp+slg,3) AS ops
FROM rates WHERE pa_proxy>=200
ORDER BY year,birth_country,player_id;
'''

COUNTRY_SQL = '''
WITH season_players AS (
 SELECT b.player_id,b.year,p.birth_country, SUM(b.ab+b.bb+b.hbp+b.sf+b.sh) AS pa_proxy
 FROM batting b JOIN people p ON p.player_id=b.player_id
 WHERE p.birth_country NOT IN ('USA','')
 GROUP BY b.player_id,b.year,p.birth_country
)
SELECT birth_country,year,COUNT(*) AS qualifying_hitters
FROM season_players WHERE pa_proxy>=200
GROUP BY birth_country,year ORDER BY year,birth_country;
'''


def export_query(db, sql, path):
    cursor = db.execute(sql)
    headers = [d[0] for d in cursor.description]
    data = [dict(r) for r in cursor.fetchall()]
    with path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader();writer.writerows(data)
    return data


def render_chart(rows, path):
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        print('matplotlib not installed; skipping chart')
        return
    totals = {}
    for row in rows:
        k=row['birth_country'];totals[k]=totals.get(k,0)+row['qualifying_hitters']
    top=sorted(totals.items(),key=lambda kv:kv[1],reverse=True)[:10]
    if not top:
        print('No qualifying hitters for chart')
        return
    labels=[r[0] for r in reversed(top)]
    values=[r[1] for r in reversed(top)]
    fig,ax=plt.subplots(figsize=(9,5.3))
    ax.barh(labels,values)
    ax.set_xlabel('Qualifying hitter-seasons (>=200 PA proxy), 2015-2025')
    ax.set_title('International-born MLB hitters by birth-country code')
    fig.tight_layout()
    fig.savefig(path,dpi=160)
    plt.close(fig)


def run(input_dir: Path, output_dir: Path, download=False):
    if download: download_data(input_dir)
    missing=[name for name in FILES if not (input_dir/name).exists()]
    if missing: raise FileNotFoundError(f'Missing {missing}; run with --download, or place SABR CSV files in {input_dir}')
    people=read_csv(input_dir/'People.csv');batting=read_csv(input_dir/'Batting.csv')
    db, batting_lines=load_data(people,batting)
    output_dir.mkdir(parents=True,exist_ok=True)
    players=export_query(db,PLAYER_SQL,output_dir/'player_seasons.csv')
    countries=export_query(db,COUNTRY_SQL,output_dir/'country_year_counts.csv')
    diagnostics={
      'source':'SABR Lahman 2025 (via attributed GitHub mirror)',
      'period':'2015-2025','people_rows':len(people),'batting_lines_in_period':batting_lines,
      'batting_lines_without_people':db.execute('SELECT COUNT(*) FROM batting b LEFT JOIN people p USING(player_id) WHERE p.player_id IS NULL').fetchone()[0],
      'players_with_missing_birth_country':db.execute("SELECT COUNT(*) FROM people WHERE birth_country='' ").fetchone()[0],
      'qualifying_player_seasons':len(players),'countries_in_qualified_sample':len({r['birth_country'] for r in players}),
      'scope_note':'Birthplace, not citizenship, national team, scouting region, or international signing status',
      'metric_note':'PA proxy=AB+BB+HBP+SF+SH; OPS=OBP+SLG, rounded',
    }
    (output_dir/'quality_report.json').write_text(json.dumps(diagnostics,indent=2)+'\n',encoding='utf-8')
    render_chart(countries,output_dir/'country_batting_seasons.png')
    print(json.dumps(diagnostics,indent=2))
    db.close()
    return diagnostics


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--download',action='store_true',help='Fetch licensed SABR Lahman CSVs into data/')
    ap.add_argument('--input',type=Path,default=ROOT/'data')
    ap.add_argument('--output',type=Path,default=ROOT/'outputs')
    args=ap.parse_args()
    run(args.input,args.output,args.download)

if __name__=='__main__':main()
