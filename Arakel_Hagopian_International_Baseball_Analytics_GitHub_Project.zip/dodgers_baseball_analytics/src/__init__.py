"""Baseball analytics project package."""
