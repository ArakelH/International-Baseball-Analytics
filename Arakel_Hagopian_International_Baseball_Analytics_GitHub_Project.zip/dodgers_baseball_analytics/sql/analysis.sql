-- SQLite analysis for MLB hitters born outside the USA, 2015-2025.
-- Not a proxy for international free-agent status or scouting eligibility.
-- Aggregate stints BEFORE calculating rate stats so traded players are not counted twice.
WITH player_seasons AS (
  SELECT b.player_id, b.year, p.first_name, p.last_name, p.birth_country,
         SUM(b.ab) ab, SUM(b.h) h, SUM(b.doubles) doubles, SUM(b.triples) triples,
         SUM(b.hr) hr, SUM(b.bb) bb, SUM(b.hbp) hbp, SUM(b.sf) sf, SUM(b.sh) sh
  FROM batting b JOIN people p ON b.player_id=p.player_id
  WHERE p.birth_country NOT IN ('USA','')
  GROUP BY b.player_id,b.year,p.first_name,p.last_name,p.birth_country
), rates AS (
 SELECT *, ab+bb+hbp+sf+sh AS pa_proxy,
        ROUND(1.0*(h+bb+hbp)/NULLIF(ab+bb+hbp+sf,0),3) AS obp,
        ROUND(1.0*(h+doubles+2*triples+3*hr)/NULLIF(ab,0),3) AS slg
 FROM player_seasons
)
SELECT player_id,year,first_name,last_name,birth_country,ab,h,hr,bb,pa_proxy,
       obp,slg,ROUND(obp+slg,3) AS ops
FROM rates WHERE pa_proxy >= 200
ORDER BY year,birth_country,player_id;
