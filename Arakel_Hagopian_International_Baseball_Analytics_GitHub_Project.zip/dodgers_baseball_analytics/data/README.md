This folder is intentionally empty. The pipeline downloads the copyrighted SABR Lahman
CSV data on first run using `--download`; those files are excluded from Git commits.

Source: https://sabr.org/lahman-database/
License: Creative Commons Attribution-ShareAlike 3.0 Unported.
