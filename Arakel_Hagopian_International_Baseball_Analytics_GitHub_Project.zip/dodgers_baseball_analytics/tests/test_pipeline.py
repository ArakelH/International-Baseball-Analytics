import tempfile
import unittest
from pathlib import Path
from src.pipeline import load_data, PLAYER_SQL, run

PEOPLE = [
 {'playerID':'player001','nameFirst':'Ana','nameLast':'One','birthCountry':'D.R.','debut':'2015-01-01'},
 {'playerID':'player002','nameFirst':'Bob','nameLast':'Two','birthCountry':'USA','debut':'2015-01-01'},
 {'playerID':'player003','nameFirst':'Cal','nameLast':'Three','birthCountry':'Cuba','debut':'2015-01-01'},
]

def batting(player,year,stint,ab,h,doubles=0,triples=0,hr=0,bb=0,hbp=0,sf=0,sh=0):
 return {'playerID':player,'yearID':str(year),'stint':str(stint),'teamID':'LAD','AB':str(ab),
         'H':str(h),'2B':str(doubles),'3B':str(triples),'HR':str(hr),'BB':str(bb),
         'HBP':str(hbp),'SF':str(sf),'SH':str(sh)}

class PipelineTests(unittest.TestCase):
 def test_aggregation_pa_and_ops(self):
  sample=[batting('player001',2024,1,100,30,5,1,3,15,2,1,0),
          batting('player001',2024,2,90,25,5,0,2,14,1,2,0),
          batting('player002',2024,1,210,100),
          batting('player003',2024,1,20,9)]
  db,_=load_data(PEOPLE,sample)
  result=[dict(r) for r in db.execute(PLAYER_SQL)]
  self.assertEqual(len(result),1)
  r=result[0]
  self.assertEqual(r['player_id'],'player001')
  self.assertEqual(r['pa_proxy'],225)
  self.assertEqual(r['obp'],round((55+29+3)/(190+29+3+3),3))
  self.assertEqual(r['slg'],round((55+10+2+15)/190,3))

 def test_reject_bad_hits(self):
  with self.assertRaisesRegex(ValueError,'Impossible'):
   load_data(PEOPLE,[batting('player001',2024,1,50,60)])

 def test_reject_duplicate_player_stint(self):
  row=batting('player001',2024,1,200,70)
  with self.assertRaisesRegex(ValueError,'Duplicate batting'):
   load_data(PEOPLE,[row,row])

 def test_zero_denominator_safe(self):
  db,_=load_data(PEOPLE,[batting('player001',2024,1,0,0,bb=220)])
  result=[dict(r) for r in db.execute(PLAYER_SQL)]
  self.assertIsNone(result[0]['slg'])
  self.assertIsNone(result[0]['ops'])

if __name__=='__main__':unittest.main()
