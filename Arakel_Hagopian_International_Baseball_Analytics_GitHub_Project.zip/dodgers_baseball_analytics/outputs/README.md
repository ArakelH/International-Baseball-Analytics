Generated analytical tables, data quality JSON, and a PNG chart will be written here
once you run the pipeline against the downloaded SABR Lahman dataset.
